# Copyright (c) Facebook, Inc. and its affiliates.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
#
import os
import copy
import argparse
import pickle
import torch
import json
import sys
import io
import random
import time
import numpy as np

from multiprocessing.pool import ThreadPool

from tqdm import tqdm, trange
from collections import OrderedDict

from torch.utils.data import DataLoader, RandomSampler, SequentialSampler, TensorDataset

from pytorch_transformers.file_utils import PYTORCH_PRETRAINED_BERT_CACHE
from pytorch_transformers.optimization import WarmupLinearSchedule
from pytorch_transformers.tokenization_bert import BertTokenizer

import blink.candidate_retrieval.utils
from blink.crossencoder.crossencoder import CrossEncoderRanker, load_crossencoder
import logging

import blink.candidate_ranking.utils as utils
import blink.biencoder.data_process as data
from blink.biencoder.zeshel_utils import DOC_PATH, WORLDS, world_to_id
from blink.common.optimizer import get_bert_optimizer
from blink.common.params import BlinkParser

from torch.cuda.amp import autocast as autocast #try amp
from torch.cuda.amp import GradScaler#amp
scaler = GradScaler()#amp
meta_scaler = GradScaler()#amp

logger = None

class MetaDataManager(object):
    def __init__(self):
        super().__init__()
    def set_data_loader(self, meta_loader):
        self.meta_loader = meta_loader
    def reset_meta_iter(self):
        self.meta_iterator = iter(self.meta_loader)
    def generate_meta_inputs(self):
        try:
            meta_batch = next(self.meta_iterator)
        except StopIteration:
            self.reset_meta_iter()
            meta_batch = next(self.meta_iterator)
        return meta_batch

def show(input,candidate):
    tokenizer = BertTokenizer.from_pretrained(
        "./bert_base_uncase/bert-base-uncased-vocab.txt", do_lower_case=params["lowercase"]
    )
    context = tokenizer.convert_ids_to_tokens(input)
    print(" ".join(context))
    for i in range(len(candidate)):
        cand = tokenizer.convert_ids_to_tokens(candidate[i])
        print(str(i)+":")
        print(cand)

def modify(context_input, candidate_input, max_seq_length):
    new_input = []
    context_input = context_input.tolist()
    candidate_input = candidate_input.tolist()

    for i in tqdm(range(len(context_input))):
        cur_input = context_input[i]
        cur_candidate = candidate_input[i]
        # if i==10:
        #     print(np.array(cur_input).shape)
        #     print(np.array(cur_candidate).shape)
        #     show(cur_input,cur_candidate)
        #     exit(0)
        mod_input = []
        for j in range(len(cur_candidate)):
            # remove [CLS] token from candidate
            sample = cur_input + cur_candidate[j][1:]
            sample = sample[:max_seq_length]
            mod_input.append(sample)

        new_input.append(mod_input)

    return torch.LongTensor(new_input)


def evaluate(reranker, eval_dataloader, device, logger, context_length, zeshel=False, silent=True):
    reranker.model.eval()
    if silent:
        iter_ = eval_dataloader
    else:
        iter_ = tqdm(eval_dataloader, desc="Evaluation")

    results = {}

    eval_accuracy = 0.0
    nb_eval_examples = 0
    nb_eval_steps = 0

    acc = {}
    tot = {}
    world_size = len(WORLDS)
    for i in range(world_size):
        acc[i] = 0.0
        tot[i] = 0.0

    all_logits = []
    cnt = 0
    for step, batch in enumerate(iter_):
        # if step>10:
        #     exit(0)
        if zeshel:
            src = batch[2]
            cnt += 1
        batch = tuple(t.to(device) for t in batch)
        context_input = batch[0]
        label_input = batch[1]
        with torch.no_grad():
            eval_loss, logits = reranker(context_input, label_input, context_length)

        logits = logits.detach().cpu().numpy()
        label_ids = label_input.cpu().numpy()

        tmp_eval_accuracy, eval_result = utils.accuracy(logits, label_ids)

        eval_accuracy += tmp_eval_accuracy
        all_logits.extend(logits)

        nb_eval_examples += context_input.size(0)
        if zeshel:
            for i in range(context_input.size(0)):
                src_w = src[i].item()
                acc[src_w] += eval_result[i]
                tot[src_w] += 1
        nb_eval_steps += 1

    normalized_eval_accuracy = -1
    if nb_eval_examples > 0:
        normalized_eval_accuracy = eval_accuracy / nb_eval_examples
    if zeshel:
        macro = 0.0
        num = 0.0 
        for i in range(len(WORLDS)):
            if acc[i] > 0:
                acc[i] /= tot[i]
                print("world:"+str(i))
                print(" acc:",str(acc[i]))
                macro += acc[i]
                num += 1
        if num > 0:
            logger.info("Macro accuracy: %.5f" % (macro / num))
            logger.info("Micro accuracy: %.5f" % normalized_eval_accuracy)
    else:
        if logger:
            logger.info("Eval accuracy: %.5f" % normalized_eval_accuracy)

    results["normalized_accuracy"] = normalized_eval_accuracy
    results["logits"] = all_logits
    return results


def get_optimizer(model, params):
    return get_bert_optimizer(
        [model],
        params["type_optimization"],
        params["learning_rate"],
        fp16=params.get("fp16"),
    )


def get_scheduler(params, optimizer, len_train_data, logger):
    batch_size = params["train_batch_size"]
    grad_acc = params["gradient_accumulation_steps"]
    epochs = params["num_train_epochs"]

    num_train_steps = int(len_train_data / batch_size / grad_acc) * epochs
    num_warmup_steps = int(num_train_steps * params["warmup_proportion"])

    scheduler = WarmupLinearSchedule(
        optimizer, warmup_steps=num_warmup_steps, t_total=num_train_steps,
    )
    logger.info(" Num optimization steps = %d" % num_train_steps)
    logger.info(" Num warmup steps = %d", num_warmup_steps)
    return scheduler


def main(params):
    model_output_path = params["output_path"]
    if not os.path.exists(model_output_path):
        os.makedirs(model_output_path)
    logger = utils.get_logger(params["output_path"])

    # Init model
    reranker = CrossEncoderRanker(params)
    tokenizer = reranker.tokenizer
    model = reranker.model

    # utils.save_model(model, tokenizer, model_output_path)

    device = reranker.device
    n_gpu = reranker.n_gpu

    if params["gradient_accumulation_steps"] < 1:
        raise ValueError(
            "Invalid gradient_accumulation_steps parameter: {}, should be >= 1".format(
                params["gradient_accumulation_steps"]
            )
        )

    # An effective batch size of `x`, when we are accumulating the gradient accross `y` batches will be achieved by having a batch size of `z = x / y`
    # args.gradient_accumulation_steps = args.gradient_accumulation_steps // n_gpu
    params["train_batch_size"] = (
        params["train_batch_size"] // params["gradient_accumulation_steps"]
    )
    train_batch_size = params["train_batch_size"]
    eval_batch_size = params["eval_batch_size"]
    meta_batch_size = 9
    grad_acc_steps = params["gradient_accumulation_steps"]

    # Fix the random seeds
    seed = params["seed"]
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if reranker.n_gpu > 0:
        torch.cuda.manual_seed_all(seed)

    max_seq_length = params["max_seq_length"]
    context_length = params["max_context_length"]

    # if not os.path.exists("cross_tensor_data"):
    train_mode = params["train_mode"]
    fname = os.path.join(params["data_path"], train_mode)
    train_data = torch.load(fname)
    context_input = train_data["context_vecs"]
    candidate_input = train_data["candidate_vecs"]
    label_input = train_data["labels"]
    if params["debug"]:
        max_n = 200
        context_input = context_input[:max_n]
        candidate_input = candidate_input[:max_n]
        label_input = label_input[:max_n]
    print("start modify...")
    context_input = modify(context_input, candidate_input, max_seq_length)
    if params["zeshel"]:
        src_input = train_data['worlds'][:len(context_input)]
        train_tensor_data = TensorDataset(context_input, label_input, src_input)
    else:
        train_tensor_data = TensorDataset(context_input, label_input)
    # print("saving cross_tensor_data....")
    # torch.save(train_tensor_data,"cross_tensor_data")
    # print("loading cross tensor data...")
    # train_tensor_data = torch.load("cross_tensor_data")
    train_sampler = RandomSampler(train_tensor_data)

    train_dataloader = DataLoader(
        train_tensor_data, 
        sampler=train_sampler, 
        batch_size=params["train_batch_size"]
    )

    #meta
    if params["meta_train"]:
        meta_mode = params["meta_mode"]
        fname = os.path.join(params["data_path"], meta_mode)
        meta_data = torch.load(fname)
        context_input = meta_data["context_vecs"]
        candidate_input = meta_data["candidate_vecs"]
        label_input = meta_data["labels"]
        if params["debug"]:
            max_n = 200
            context_input = context_input[:max_n]
            candidate_input = candidate_input[:max_n]
            label_input = label_input[:max_n]
        print("modifying meta...")
        context_input = modify(context_input, candidate_input, max_seq_length)
        if params["zeshel"]:
            src_input = meta_data["worlds"][:len(context_input)]
            meta_tensor_data = TensorDataset(context_input, label_input, src_input)
        else:
            meta_tensor_data = TensorDataset(context_input, label_input)
        meta_sampler = RandomSampler(meta_tensor_data)

        meta_dataloader = DataLoader(
            meta_tensor_data, 
            sampler=meta_sampler, 
            batch_size=meta_batch_size,
            drop_last = True
        )
        meta_manager = MetaDataManager()
        meta_manager.set_data_loader(meta_dataloader)
        meta_manager.reset_meta_iter()

    #test
    valid_mode = params["valid_mode"]
    fname = os.path.join(params["data_path"], valid_mode)
    valid_data = torch.load(fname)
    context_input = valid_data["context_vecs"]
    candidate_input = valid_data["candidate_vecs"]
    label_input = valid_data["labels"]
    # print(label_input[:15])
    if params["debug"]:
        max_n = 200
        context_input = context_input[:max_n]
        candidate_input = candidate_input[:max_n]
        label_input = label_input[:max_n]
    print("modifying valid...")
    context_input = modify(context_input, candidate_input, max_seq_length)
    if params["zeshel"]:
        src_input = valid_data["worlds"][:len(context_input)]
        valid_tensor_data = TensorDataset(context_input, label_input, src_input)
    else:
        valid_tensor_data = TensorDataset(context_input, label_input)
    valid_sampler = SequentialSampler(valid_tensor_data)

    valid_dataloader = DataLoader(
        valid_tensor_data, 
        sampler=valid_sampler, 
        batch_size=params["eval_batch_size"]
    )

    # evaluate before training
    results = evaluate(
        reranker,
        valid_dataloader,
        device=device,
        logger=logger,
        context_length=context_length,
        zeshel=params["zeshel"],
        silent=params["silent"],
    )

    number_of_samples_per_dataset = {}

    time_start = time.time()

    utils.write_to_file(
        os.path.join(model_output_path, "training_params.txt"), str(params)
    )

    logger.info("Starting training")
    logger.info(
        "device: {} n_gpu: {}, distributed training: {}".format(device, n_gpu, False)
    )

    optimizer = get_optimizer(model, params)
    scheduler = get_scheduler(params, optimizer, len(train_tensor_data), logger)

    model.train()

    best_epoch_idx = -1
    best_score = -1

    num_train_epochs = params["num_train_epochs"]

    best_normalized_accuracy = 0
    
    for epoch_idx in trange(int(num_train_epochs), desc="Epoch"):
        tr_loss = 0
        results = None

        if params["silent"]:
            iter_ = train_dataloader
        else:
            iter_ = tqdm(train_dataloader, desc="Batch")

        part = 0
        if params["meta_train"]:
            valid_step = 0
            cuda1 = torch.device("cuda:1")
            for step, batch in enumerate(iter_):
                batch = tuple(t.to(cuda1) for t in batch)
                context_input = batch[0] 
                label_input = batch[1]
                #generate meta model
                meta_reranker = copy.deepcopy(reranker)#自带reranker已有的梯度
                meta_reranker.zero_grad()#清除梯度
                meta_reranker.to(cuda1)
                meta_reranker.device = cuda1
                meta_optimizer = get_optimizer(meta_reranker.model, params)
                #compute ori loss
                meta_reranker.eval()
                ori_meta_loss = 0
                meta_batch = meta_manager.generate_meta_inputs()
                context_meta,label_meta = meta_batch[0].to(cuda1),meta_batch[1].to(cuda1)
                with torch.no_grad():
                    with autocast():
                        meta_loss, _ = meta_reranker(context_meta, label_meta, context_length)
                ori_meta_loss +=  meta_loss.item()
                del meta_loss
                print("\nori_meta_loss:",ori_meta_loss)

                meta_reranker.train()
                #update meta model
                with autocast():
                    meta_loss , _ = meta_reranker(context_input, label_input, context_length)
                meta_scaler.scale(meta_loss).backward()
                meta_scaler.step(meta_optimizer)
                meta_scaler.update()
                meta_optimizer.zero_grad()
                context_input, label_input = context_input.to(device), label_input.to(device)
               
                #compute new loss
                meta_reranker.eval()
                new_meta_loss = 0
                with torch.no_grad():
                    with autocast():
                        meta_loss, _ = meta_reranker(context_meta, label_meta, context_length)
                new_meta_loss += meta_loss.item()
                del meta_loss
                print("new_meta_loss:",new_meta_loss)
                if new_meta_loss < ori_meta_loss:
                    with autocast():# amp step 1 
                        loss, _ = reranker(context_input, label_input, context_length)
                        if grad_acc_steps > 1:
                            loss = loss / grad_acc_steps         
                    # if n_gpu > 1:
                    #     loss = loss.mean() # mean() to average on multi-gpu.
                    tr_loss += loss.item()

                    if (valid_step + 1) % (params["print_interval"] * grad_acc_steps*train_batch_size) == 0:
                        logger.info(
                            "Step {} - epoch {} average loss: {}\n".format(
                                valid_step//train_batch_size,
                                epoch_idx,
                                tr_loss / (params["print_interval"] * grad_acc_steps),
                            )
                        )
                        tr_loss = 0
                    # loss.backward()
                    scaler.scale(loss).backward() #amp step 2

                    if (valid_step + 1) % (grad_acc_steps*train_batch_size) == 0:
                        torch.nn.utils.clip_grad_norm_(
                            model.parameters(), params["max_grad_norm"]
                        )
                        # optimizer.step()
                        scaler.step(optimizer) #amp step 3
                        scaler.update()# amp step 4 
                        scheduler.step()
                        optimizer.zero_grad()

                    if (valid_step + 1) % (params["eval_interval"] * grad_acc_steps*train_batch_size) == 0:
                        logger.info("Evaluation on the development dataset")
                        res = evaluate(
                            reranker,
                            valid_dataloader,
                            device=device,
                            logger=logger,
                            context_length=context_length,
                            zeshel=params["zeshel"],
                            silent=params["silent"],
                        )
                        if res["normalized_accuracy"] > best_normalized_accuracy:
                            best_normalized_accuracy = res["normalized_accuracy"]
                            logger.info("normalized_accuracy:"+str(best_normalized_accuracy))
                            logger.info("***** Saving fine - tuned model *****")
                            epoch_output_folder_path = os.path.join(
                                model_output_path, "epoch_{}_{}".format(epoch_idx, part)
                            )
                            part += 1
                            utils.save_model(model, tokenizer, epoch_output_folder_path)
                        model.train()
                        logger.info("\n")
                    valid_step += 1
                logger.info("track accepted ratio:"+str(step)+" "+str(valid_step)+" "+str(valid_step//train_batch_size))
                logger.info("ori_loss:"+str(ori_meta_loss))

        else:
            for step, batch in enumerate(iter_):
                batch = tuple(t.to(device) for t in batch)
                context_input = batch[0] 
                label_input = batch[1]
                with autocast():# amp step 1 
                    loss, _ = reranker(context_input, label_input, context_length)
                    if grad_acc_steps > 1:
                        loss = loss / grad_acc_steps
                # if n_gpu > 1:
                #     loss = loss.mean() # mean() to average on multi-gpu.
                tr_loss += loss.item()

                if (step + 1) % (params["print_interval"] * grad_acc_steps) == 0:
                    logger.info(
                        "Step {} - epoch {} average loss: {}\n".format(
                            step,
                            epoch_idx,
                            tr_loss / (params["print_interval"] * grad_acc_steps),
                        )
                    )
                    tr_loss = 0

                # loss.backward()
                scaler.scale(loss).backward() #amp step 2

                if (step + 1) % grad_acc_steps == 0:
                    torch.nn.utils.clip_grad_norm_(
                        model.parameters(), params["max_grad_norm"]
                    )
                    # optimizer.step()
                    scaler.step(optimizer) #amp step 3
                    scaler.update()# amp step 4 
                    scheduler.step()
                    optimizer.zero_grad()

                if (step + 1) % (params["eval_interval"] * grad_acc_steps) == 0:
                    logger.info("Evaluation on the development dataset")
                    res = evaluate(
                        reranker,
                        valid_dataloader,
                        device=device,
                        logger=logger,
                        context_length=context_length,
                        zeshel=params["zeshel"],
                        silent=params["silent"],
                    )
                    if res["normalized_accuracy"] > best_normalized_accuracy:
                        best_normalized_accuracy = res["normalized_accuracy"]
                        logger.info("normalized_accuracy:"+str(best_normalized_accuracy))
                        logger.info("***** Saving fine - tuned model *****")
                        epoch_output_folder_path = os.path.join(
                            model_output_path, "epoch_{}_{}".format(epoch_idx, part)
                        )
                        part += 1
                        utils.save_model(model, tokenizer, epoch_output_folder_path)
                    model.train()
                    logger.info("\n")

        logger.info("***** Saving fine - tuned model *****")
        epoch_output_folder_path = os.path.join(
            model_output_path, "epoch_{}".format(epoch_idx)
        )
        utils.save_model(model, tokenizer, epoch_output_folder_path)
        # reranker.save(epoch_output_folder_path)

        output_eval_file = os.path.join(epoch_output_folder_path, "eval_results.txt")
        results = evaluate(
            reranker,
            valid_dataloader,
            device=device,
            logger=logger,
            context_length=context_length,
            zeshel=params["zeshel"],
            silent=params["silent"],
        )

        ls = [best_score, results["normalized_accuracy"]]
        li = [best_epoch_idx, epoch_idx]

        best_score = ls[np.argmax(ls)]
        best_epoch_idx = li[np.argmax(ls)]
        logger.info("\n")

    execution_time = (time.time() - time_start) / 60
    utils.write_to_file(
        os.path.join(model_output_path, "training_time.txt"),
        "The training took {} minutes\n".format(execution_time),
    )
    logger.info("The training took {} minutes\n".format(execution_time))

    # save the best model in the parent_dir
    logger.info("Best performance in epoch: {}".format(best_epoch_idx))
    params["path_to_model"] = os.path.join(
        model_output_path, "epoch_{}".format(best_epoch_idx)
    )


if __name__ == "__main__":
    parser = BlinkParser(add_model_args=True)
    parser.add_training_args()
    parser.add_eval_args()

    parser.add_argument(
        "--meta_train",
        action="store_true",
    )
    parser.add_argument(
        "--train_mode",
        type=str,
    )
    parser.add_argument(
        "--valid_mode",
        type=str,
    )
    parser.add_argument(
        "--meta_mode",
        type=str,
    )
    # args = argparse.Namespace(**params)
    args = parser.parse_args()
    print(args)

    params = args.__dict__
    main(params)
