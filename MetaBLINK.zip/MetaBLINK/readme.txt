We present the codes for our paper "Effective Few-Shot Named Entity Linking by Meta-Learning".

The MetaBLINK consists of bi-encoder module and cross-encoder module, and both of them adopt a meta-learning mechanism for updating their parameters. 

The directory biencoder contains codes for training and evaluating the bi-encoder module, the directory crossencoder contains codes for training and evaluating the cross-encoder module, and the directory mg contains codes for generating synthetic data.
