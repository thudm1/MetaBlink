import torch
import json
from torch.utils.data import IterableDataset
from torch.utils.data import DataLoader, Dataset, SequentialSampler, RandomSampler
from collections import Iterator,Iterable
import numpy as np

class QueryGeneratorExample:
    def __init__(self, ids, labels):
        self.ids = ids
        self.labels = labels

def generate_train_features(samples, max_seq_length, tokenizer):
    cnt = 0
    l = len(samples)
    while cnt<l:
        mention,label,context_left,context_right = samples[cnt]
        print(max_seq_length)
        max_label_length = max_seq_length//2 - 2
        max_context_length = max_seq_length//4
        prefix = "summarize: "#occupies 2 tokens
        context_left = tokenizer.decode(tokenizer.encode(context_left)[-max_context_length:]).replace("</s>","")
        context_right = tokenizer.decode(tokenizer.encode(context_right,truncation = True, max_length=max_context_length)).replace("</s>","")
        label = tokenizer.decode(tokenizer.encode(label,truncation = True, max_length=max_label_length)).replace("</s>","")
        input_str = prefix + context_left + '<|LEFT|>' + label + '<|RIGHT|>' + context_right 
        label_str = mention
        yield QueryGeneratorExample(ids=input_str, labels=label_str)
        cnt += 1

class IterableTrainDataset(IterableDataset):
    def __init__(self, train_file, max_seq_length, tokenizer):
        super(IterableTrainDataset).__init__()
        print("loading file:",train_file)
        samples = []
        f = open(train_file, 'r')
        line = f.readline()
        while line:
            line = json.loads(line)
            mention = line["mention"]
            label = line["label"]
            context_left = line["context_left"]
            context_right = line["context_right"]
            samples.append((mention,label,context_left,context_right))
            line = f.readline()
        print("load done,totally %d samples",len(samples))
        f.close()
        self.gen = generate_train_features(samples, max_seq_length, tokenizer)

    def __iter__(self):
        return self.gen

def mention_generator_train_dataloader(train_file, tokenizer, batch_size, max_seq_length):
    dataset = IterableTrainDataset(train_file, max_seq_length, tokenizer)
    def _collate_fn(batch_dataset):
        batch = [[], []]
        for example in batch_dataset:
            batch[0].append(example.ids)
            batch[1].append(example.labels)
        #目前的问题是max_seq设置成了256，但是print(len(encodings['input_ids']))显示128？另外确认一下eos_token是否要手动加
        encodings = tokenizer(batch[0] + batch[1], return_tensors='pt', padding='longest')
        print(len(encodings['input_ids']))
        exit(0)
        half_size = len(encodings['input_ids'])//2
        input_id = encodings['input_ids'][: half_size]
        label_id = encodings['input_ids'][half_size: half_size * 2]
        input_mask = encodings['attention_mask'][:half_size]
        label_mask = encodings['attention_mask'][half_size: half_size * 2]
        batch = tuple([input_id, label_id, input_mask, label_mask])
        return batch
    return DataLoader(dataset, batch_size=batch_size, collate_fn=_collate_fn)
