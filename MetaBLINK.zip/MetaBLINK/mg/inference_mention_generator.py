import argparse
import os
import random
import json
import numpy as np
import torch
from tqdm import tqdm, trange
from transformers import T5Tokenizer, T5ForConditionalGeneration
import csv


def set_seed(args):
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)


def to_list(tensor):
    return tensor.detach().cpu().tolist()


class InferenceModel:
    def __init__(self, args):
        self.tokenizer = T5Tokenizer.from_pretrained(args.model_load_path)
        self.model = T5ForConditionalGeneration.from_pretrained(args.model_name)
        # self.model.resize_token_embeddings(len(self.tokenizer))
        print("load model from:",args.model_load_path)
        self.model.load_state_dict(torch.load(args.model_load_path + '/models.pkl'))
        self.model.to(args.device)
        self.model.eval()

        self.device = args.device
        self.temperature = args.temperature
        self.top_p = args.top_p
        self.max_input_length = args.max_input_length
        self.max_output_length = args.max_output_length
        # self.max_doc_length = (self.max_input_length - 3) // 2

        # self.special_tokens = ['<|NEG|>', '<|POS|>', "<|QRY|>"]
        # [self.neg_token_id, self.pos_token_id, self.qry_token_id] = self.tokenizer.convert_tokens_to_ids(self.special_tokens)
        self.eos_token_id = self.tokenizer.eos_token_id
        self.pad_token_id = self.tokenizer.pad_token_id

    def get_input_seq(self, des):
        des = "summarize: "+des
        input_ids = self.tokenizer.encode(des, max_length=self.max_input_length,truncation=True)
        # input_ids = [self.pos_token_id] + input_ids + [self.eos_token_id]
        assert len(input_ids) <= self.max_input_length
        return input_ids

    # def get_input_seq_from_pair(self, pos_doc, neg_doc):
    #     neg_doc_ids = self.tokenizer.encode(neg_doc, max_length=self.max_doc_length)
    #     pos_doc_ids = self.tokenizer.encode(pos_doc, max_length=self.max_doc_length)
    #     input_ids = [self.pos_token_id] + pos_doc_ids + [self.neg_token_id] + neg_doc_ids + [self.eos_token_id]
    #     assert len(input_ids) <= self.max_input_length
    #     return input_ids

    # def remove_special_tokens(self, text):
    #     # Remove special tokens from the output text in rare cases
    #     for token in self.special_tokens:
    #         text = text.replace(token, "")
    #     return text

    def predict(self, des):
        input_ids =  self.get_input_seq(des)

        input_ids = torch.Tensor(input_ids).long().to(self.device).unsqueeze(0)
        output = self.model.generate(input_ids=input_ids, max_length=self.max_output_length, top_p=self.top_p, temperature=self.temperature).squeeze()
        pred_text = self.tokenizer.decode(output)
        # pred_text = self.remove_special_tokens(pred_text)
        
        return pred_text


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_name", type=str, default='t5-small')
    parser.add_argument("--model_load_path", type=str, required=True)
    parser.add_argument("--inference_file", type=str, required=True)
    parser.add_argument("--output_file", type=str, required=True)
    parser.add_argument("--per_gpu_eval_batch_size", type=int, default=2)
    parser.add_argument("--max_sample", type=int, default=640000)
    parser.add_argument("--max_input_length", type=int, default=256)
    parser.add_argument("--max_output_length", type=int, default=32, help="Maximum length of output sequence")
    # parser.add_argument("--min_output_length", type=int, default=20)
    parser.add_argument("--temperature", type=float, default=1.0, help="temperature of 1 implies greedy sampling")
    parser.add_argument("--top_p", type=float, default=0.9)
    parser.add_argument("--debug", action='store_true')
    parser.add_argument("--retry_times", type=int, default=3)
    args = parser.parse_args()

    args.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    args.n_gpu = torch.cuda.device_count()
    args.seed = 42
    set_seed(args)

    inference_model = InferenceModel(args)

    des_items = []
    with open(args.inference_file) as f:
        for i, line in enumerate(f):
            if i >= args.max_sample:
                break
            data = json.loads(line)
            des_items.append([data['golden_label'], data['des']])  # doc_id, pos_doc
    print("output:",args.output_file)
    with open(args.output_file, 'w') as f:
        for p in tqdm(des_items):
            prediction = ''
            prediction = inference_model.predict(p[1])
            data = {'des': p[1], 'golden_label':p[0],'predict': prediction}  # qid, query
            f.write(json.dumps(data) + '\n')
            f.flush()


if __name__ == '__main__':
    main()
