步骤：
1.gen_data.py 中转换格式
2. inference_mg.sh
3.gen_data.py 中生成新的训练文件