import json
import enchant
import inflect
p = inflect.engine()
d = enchant.Dict("en_US")

def no_overlap(m,title):
    m_l = set(m.split())
    m_l2 = set(p.singular_noun(item) for item in m.split())
    m_l = m_l | m_l2
    t_l = set(title.split())
    if len(m_l & t_l)>0:
        return False
    return True
    # if m in title or title in m:
    #     return False
    # return True
def contains_number(m):
    for item in m.split():
        if item.isdigit():
            return True
    return False

def check(mention):
    l = mention.split()
    for item in l:
        if not d.check(item):
            return False
    return True

# src = open("../data/zeshel/blink_format/train.jsonl")
# out = open("./data/train_mentions_with_context.jsonl",'w')
# line = src.readline()
# filtered = 0
# cnt = 0
# while line:
#     line = json.loads(line)
#     new_line = {}
#     cnt += 1
#     if not no_overlap(line["mention"].lower(),line["label_title"].lower()):
#         filtered += 1
#         line = src.readline()
#         continue
#     new_line["mention"] = line["mention"]
#     new_line["label"] = line["label"]
#     new_line["context_left"] = line["context_left"]
#     new_line["context_right"] = line["context_right"]
#     out.write(json.dumps(new_line)+"\n")
#     line = src.readline()
# print("filtered:",filtered)
# print("cnt:",cnt)

# #转换格式
# src = open("../exact_star_trek.jsonl")
# out = open("./data/inference_exact_star_trek.jsonl",'w')
# line = src.readline()
# while line:
#     line = json.loads(line)
#     new_line = {}
#     new_line["golden_label"] = line["label_title"]
#     new_line["des"] = line["label"]
#     out.write(json.dumps(new_line)+"\n")
#     line = src.readline()

# #生成新的训练文件
succ = 0
cnt = 0
assi_f = open("./data/inference_star_trek_res.jsonl")
src_f = open("../exact_star_trek.jsonl")
# src_f = open("../data/zeshel/blink_format/pseudo_lego_corenlp.jsonl")
out_f = open("./data/sync_mg_star_trek.jsonl",'w')
out_f2 = open("./data/exact_star_trek_for_compare.jsonl",'w')
src_line = src_f.readline()
assi_line = assi_f.readline()

exist_entitys = []
exist_mentions = []

while src_line and assi_line:
    src_line = json.loads(src_line)
    assi_line = json.loads(assi_line)
    if src_line["label_title"].lower() == assi_line["golden_label"].lower():
        cnt+=1
        title = src_line["label_title"].lower()
        new_m = assi_line["predict"]
        new_m = new_m.replace("<pad>","").replace("</s>","").strip().lower()
        # if len(new_m.split())>2 and len(new_m.split())<4 and title not in exist_entitys and new_m not in exist_mentions and no_overlap(new_m,title) and not contains_number(new_m) and check(new_m):
        # if check(new_m):
        if True:
            succ+=1
            out_f2.write(json.dumps(src_line)+"\n")
            src_line["mention"] = new_m
            exist_entitys.append(title)
            exist_mentions.append(new_m)
            out_f.write(json.dumps(src_line)+"\n")
    src_line = src_f.readline()
    assi_line = assi_f.readline()

src_f.close()
assi_f.close()
out_f.close()
print("cnt:",cnt)
print("succ",succ)