import argparse
import os
from torch.utils.tensorboard import SummaryWriter
from datetime import datetime
import torch
from transformers import T5Tokenizer, T5ForConditionalGeneration, AdamW
from dataloaders import mention_generator_train_dataloader


def save_model(model, optimizer, tokenizer, model_save_path, postfix, log):
    save_path = model_save_path + postfix
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    print(f"Saving query model to {save_path}...", flush=True)
    log.write(f"Saving query model to {save_path}...\n")

    torch.save(model.state_dict(), save_path + '/models.pkl')
    tokenizer.save_pretrained(save_path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_name", type=str, default='../t5-small/')
    parser.add_argument("--model_load_dir", type=str)
    parser.add_argument("--model_save_dir", type=str, required=True)
    parser.add_argument("--train_file", type=str, default='./data/train_mentions.jsonl')
    parser.add_argument("--log_path", type=str, default='./log.txt')
    parser.add_argument("--tensorboard_dir", type=str, default=None)
    parser.add_argument("--per_gpu_train_batch_size", type=int, default=2)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=1)
    parser.add_argument("--logging_steps", type=int, default=20)
    parser.add_argument("--save_steps", type=int, default=50000)
    parser.add_argument("--max_seq_length", type=int, default=256)
    parser.add_argument("--lr", type=float, default=2e-5)
    parser.add_argument("--id", type=str, default='0')
    parser.add_argument("--epoch", type=int, default=1)
    args = parser.parse_args()

    args.model_save_path = os.path.join(args.model_save_dir, 'mention_gen_'+args.id+'-'+datetime.now().strftime("%Y-%m-%d_%H-%M-%S"))
    writer = None
    if args.tensorboard_dir:
        writer = SummaryWriter(args.tensorboard_dir)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    args.n_gpu = torch.cuda.device_count()

    if args.model_load_dir:
        tokenizer = T5Tokenizer.from_pretrained(args.model_load_dir)
        model = T5ForConditionalGeneration.from_pretrained(args.model_name)
        model.resize_token_embeddings(len(tokenizer))
        model.load_state_dict(torch.load(args.model_load_dir + '/models.pkl'))
    else:
        print("use special tokens...")
        tokenizer = T5Tokenizer.from_pretrained(args.model_name)
        tokenizer.add_tokens(['<|LEFT|>', '<|RIGHT|>'])
        model = T5ForConditionalGeneration.from_pretrained(args.model_name)
        model.resize_token_embeddings(len(tokenizer))
    model.to(device)

    # [des_token_id, eos_token_id] = tokenizer.convert_tokens_to_ids([ "<|DES|>", "<|EOS|>"])
    # print(des_token_id, eos_token_id)

    train_batch_size = args.per_gpu_train_batch_size * max(1, args.n_gpu)
    
    no_decay = ['bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [
        {'params': [p for n, p in model.named_parameters() if not any(nd in n for nd in no_decay)], 'weight_decay': 0.0},
        {'params': [p for n, p in model.named_parameters() if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
        ]
    optimizer = AdamW(optimizer_grouped_parameters, lr=args.lr, eps=1e-8)

    # if args.n_gpu > 1:
    #     model = torch.nn.DataParallel(model)

    log = open(args.log_path, 'w')

    #save a raw model
    postfix = "_step" + str(0)
    save_model(model, optimizer, tokenizer, args.model_save_path, postfix, log)

    global_step = 0
    for epoch in range(args.epoch):
        train_dataloader = mention_generator_train_dataloader(args.train_file, tokenizer, train_batch_size, args.max_seq_length)
        model.train()
        model.zero_grad()
        tr_loss = 0
        for step, batch in enumerate(train_dataloader):
            batch = tuple(t.to(device) for t in batch)
            (input_id, label_id, input_mask, label_mask) = batch
            # print(input_id)
            # print(label_id)
            # print(input_mask)
            # print(label_mask)
            outputs = model(input_ids=input_id, attention_mask=input_mask, labels=label_id)
            loss = outputs[0]
            # print(loss)
            # print(args.n_gpu)
            # if args.n_gpu > 1:
            #     loss = loss.mean()
            # print(loss)
            # exit(0)
            tr_loss += loss.item()
            loss = loss / args.gradient_accumulation_steps
            loss.backward()

            if (step + 1) % args.gradient_accumulation_steps == 0:
                optimizer.step()
                optimizer.zero_grad()

            if (global_step + 1) % args.logging_steps == 0:
                print(f"After {global_step + 1} steps, loss: {tr_loss / args.logging_steps}")
                log.write(f"After {global_step + 1} steps, loss: {tr_loss / args.logging_steps}\n")
                if writer:
                    writer.add_scalar('train loss', tr_loss / args.logging_steps, global_step + 1)
                tr_loss = 0

            if (global_step + 1) % args.save_steps == 0:
                postfix = "_step" + str(global_step + 1)
                save_model(model, optimizer, tokenizer, args.model_save_path, postfix, log)
                
            global_step += 1

        save_model(model, optimizer, tokenizer, args.model_save_path, '_epoch'+str(epoch+1), log)

    save_model(model, optimizer, tokenizer, args.model_save_path, '_all', log)


if __name__ == '__main__':
    main()
